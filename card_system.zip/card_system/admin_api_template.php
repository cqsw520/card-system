<?php
/**
 * 后台 API 接口
 * 仅管理员可访问，前台无法调用
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db/init.php';
require_once __DIR__ . '/../lib/Security.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/CardManager.php';
require_once __DIR__ . '/../lib/OrderManager.php';

header('Content-Type: application/json; charset=utf-8');

// 验证管理员权限
Auth::verifyApiRequest();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    
    // 批量生成卡密
    case 'generate_cards':
        $count = intval($_POST['count'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $duration = intval($_POST['duration'] ?? DEFAULT_DURATION);
        $remark = $_POST['remark'] ?? '';
        
        if ($count < 1 || $count > 1000) {
            echo json_encode(['success' => false, 'msg' => '数量范围 1-1000']);
            break;
        }
        if ($amount < 0) {
            echo json_encode(['success' => false, 'msg' => '额度不能为负']);
            break;
        }
        if ($duration < 1 || $duration > 3650) {
            echo json_encode(['success' => false, 'msg' => '有效期范围 1-3650 天']);
            break;
        }
        
        $result = CardManager::generateBatch($count, $amount, $duration, $remark);
        echo json_encode($result);
        break;
    
    // 禁用卡密
    case 'disable_card':
        $cardId = intval($_POST['card_id'] ?? 0);
        if (CardManager::disableCard($cardId)) {
            echo json_encode(['success' => true, 'msg' => '已禁用']);
        } else {
            echo json_encode(['success' => false, 'msg' => '操作失败']);
        }
        break;
    
    // 删除卡密
    case 'delete_card':
        $cardId = intval($_POST['card_id'] ?? 0);
        if (CardManager::deleteCard($cardId)) {
            echo json_encode(['success' => true, 'msg' => '已删除']);
        } else {
            echo json_encode(['success' => false, 'msg' => '删除失败']);
        }
        break;
    
    // 导出卡密
    case 'export':
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="cards_export_' . date('YmdHis') . '.csv"');
        
        $batchNo = $_GET['batch'] ?? '';
        $status = intval($_GET['status'] ?? -1);
        $cards = CardManager::exportCards($batchNo, $status);
        
        echo "\xEF\xBB\xBF"; // BOM for Excel
        echo "卡号,卡密,额度,有效期(天),状态,批次号,创建时间,激活时间,到期时间,绑定设备\n";
        
        $statusMap = [0=>'未使用',1=>'已激活',2=>'已过期',3=>'已禁用'];
        foreach ($cards as $c) {
            echo implode(',', [
                $c['card_key'],
                $c['card_secret'],
                $c['amount'],
                $c['duration'],
                $statusMap[$c['status']] ?? '未知',
                $c['batch_no'],
                date('Y-m-d H:i:s', $c['created_at']),
                $c['activated_at'] ? date('Y-m-d H:i:s', $c['activated_at']) : '',
                $c['expired_at'] ? date('Y-m-d H:i:s', $c['expired_at']) : '',
                $c['device_id'] ?? ''
            ]) . "\n";
        }
        exit;
    
    // 添加套餐
    case 'add_package':
        $name = trim($_POST['name'] ?? '');
        $amount = floatval($_POST['amount'] ?? 0);
        $duration = intval($_POST['duration'] ?? 30);
        $price = floatval($_POST['price'] ?? 0);
        $stock = intval($_POST['stock'] ?? 0);
        
        if (!$name) {
            echo json_encode(['success' => false, 'msg' => '请输入套餐名称']);
            break;
        }
        
        $db = Database::getInstance();
        $id = $db->insert(
            "INSERT INTO packages (name, amount, duration, price, stock) VALUES (?, ?, ?, ?, ?)",
            [$name, $amount, $duration, $price, $stock]
        );
        
        if ($id) {
            echo json_encode(['success' => true, 'msg' => '添加成功']);
        } else {
            echo json_encode(['success' => false, 'msg' => '添加失败']);
        }
        break;
    
    // 切换套餐状态
    case 'toggle_package':
        $pkgId = intval($_POST['package_id'] ?? 0);
        $status = intval($_POST['status'] ?? 0);
        
        $db = Database::getInstance();
        if ($db->update("UPDATE packages SET status = ? WHERE id = ?", [$status, $pkgId])) {
            echo json_encode(['success' => true, 'msg' => '更新成功']);
        } else {
            echo json_encode(['success' => false, 'msg' => '更新失败']);
        }
        break;
    
    // 修改密码
    case 'change_password':
        $oldPwd = $_POST['old_password'] ?? '';
        $newPwd = $_POST['new_password'] ?? '';
        $newPwd2 = $_POST['new_password2'] ?? '';
        
        if (strlen($newPwd) < 8) {
            echo json_encode(['success' => false, 'msg' => '新密码至少8个字符']);
            break;
        }
        if ($newPwd !== $newPwd2) {
            echo json_encode(['success' => false, 'msg' => '两次密码不一致']);
            break;
        }
        
        $db = Database::getInstance();
        $admin = $db->fetch("SELECT password_hash FROM admins WHERE id = ?", [$_SESSION['admin_id']]);
        
        if (!$admin || !Security::verifyPassword($oldPwd, $admin['password_hash'])) {
            echo json_encode(['success' => false, 'msg' => '当前密码错误']);
            break;
        }
        
        $newHash = Security::hashPassword($newPwd);
        if ($db->update("UPDATE admins SET password_hash = ? WHERE id = ?", [$newHash, $_SESSION['admin_id']])) {
            echo json_encode(['success' => true, 'msg' => '密码修改成功']);
        } else {
            echo json_encode(['success' => false, 'msg' => '修改失败']);
        }
        break;
    
    // 获取仪表盘数据
    case 'get_stats':
        echo json_encode(['success' => true, 'data' => CardManager::getStats()]);
        break;
    
    default:
        echo json_encode(['success' => false, 'msg' => '未知操作']);
}
