<?php
/**
 * 后台管理首页
 * 包含：仪表盘、卡密管理、订单管理、套餐管理
 * 路径随机化，仅管理员可访问
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db/init.php';
require_once __DIR__ . '/../lib/Security.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/CardManager.php';

Auth::requireAdmin();

$db = Database::getInstance();
$stats = CardManager::getStats();
$csrfToken = Security::generateCsrfToken();

// 分页参数
$page = max(1, intval($_GET['page'] ?? 1));
$status = intval($_GET['status'] ?? -1);
$search = trim($_GET['search'] ?? '');
$pageSize = 20;

$cardsData = CardManager::getCards($page, $pageSize, $status, $search);
$totalPages = ceil($cardsData['total'] / $pageSize);

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>管理后台 - 卡密系统</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
    background: #0a0e27;
    color: #e0e0e0;
    min-height: 100vh;
}
.layout { display: flex; min-height: 100vh; }
/* 侧边栏 */
.sidebar {
    width: 240px;
    background: #0d1137;
    border-right: 1px solid rgba(255,255,255,0.05);
    padding: 24px 0;
    position: fixed;
    top: 0; left: 0; bottom: 0;
    overflow-y: auto;
}
.sidebar .logo {
    padding: 0 24px 24px;
    font-size: 18px;
    font-weight: 700;
    color: #fff;
    border-bottom: 1px solid rgba(255,255,255,0.05);
    margin-bottom: 16px;
}
.sidebar .logo small {
    display: block;
    font-size: 11px;
    color: #4caf50;
    margin-top: 4px;
}
.nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 24px;
    color: #888;
    text-decoration: none;
    font-size: 14px;
    transition: all 0.3s;
    cursor: pointer;
    border: none;
    background: none;
    width: 100%;
    text-align: left;
}
.nav-item:hover { background: rgba(102,126,234,0.1); color: #fff; }
.nav-item.active { background: rgba(102,126,234,0.15); color: #667eea; border-right: 3px solid #667eea; }
.nav-item .icon { font-size: 18px; width: 24px; text-align: center; }
/* 主内容 */
.main { margin-left: 240px; flex: 1; padding: 24px 32px; }
.top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 32px;
}
.top-bar h1 { font-size: 22px; color: #fff; }
.top-bar .user-info { display: flex; align-items: center; gap: 12px; }
.top-bar .user-info span { font-size: 14px; color: #888; }
.btn-sm {
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.3s;
}
.btn-danger { background: rgba(244,67,54,0.15); color: #f44336; }
.btn-danger:hover { background: rgba(244,67,54,0.25); }
.btn-outline { background: transparent; border: 1px solid rgba(255,255,255,0.1); color: #888; }
.btn-outline:hover { border-color: #667eea; color: #667eea; }

/* 统计卡片 */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 32px;
}
.stat-card {
    background: linear-gradient(145deg, #111530, #0f1229);
    border: 1px solid rgba(102,126,234,0.1);
    border-radius: 12px;
    padding: 20px;
}
.stat-card .label { font-size: 13px; color: #666; margin-bottom: 8px; }
.stat-card .value { font-size: 28px; font-weight: 700; }
.stat-card .value.green { color: #4caf50; }
.stat-card .value.blue { color: #667eea; }
.stat-card .value.orange { color: #ff9800; }
.stat-card .value.red { color: #f44336; }
.stat-card .value.purple { color: #a78bfa; }

/* 内容区域 */
.content-section { display: none; }
.content-section.active { display: block; }

/* 表格 */
.data-table {
    width: 100%;
    border-collapse: collapse;
    background: linear-gradient(145deg, #111530, #0f1229);
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid rgba(102,126,234,0.1);
}
.data-table th {
    background: rgba(102,126,234,0.08);
    padding: 14px 16px;
    text-align: left;
    font-size: 12px;
    color: #888;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.data-table td {
    padding: 14px 16px;
    font-size: 14px;
    border-top: 1px solid rgba(255,255,255,0.03);
    color: #ccc;
}
.data-table tr:hover td { background: rgba(102,126,234,0.03); }
.status-badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
}
.status-0 { background: rgba(255,152,0,0.15); color: #ff9800; }
.status-1 { background: rgba(76,175,80,0.15); color: #4caf50; }
.status-2 { background: rgba(244,67,54,0.15); color: #f44336; }
.status-3 { background: rgba(158,158,158,0.15); color: #9e9e9e; }

/* 工具栏 */
.toolbar {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
    flex-wrap: wrap;
    align-items: center;
}
.toolbar input, .toolbar select {
    padding: 10px 14px;
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 8px;
    color: #fff;
    font-size: 14px;
}
.toolbar input:focus, .toolbar select:focus {
    outline: none;
    border-color: #667eea;
}
.btn-primary {
    padding: 10px 20px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}
.btn-primary:hover { opacity: 0.9; }

/* 模态框 */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.7);
    z-index: 1000;
    align-items: center;
    justify-content: center;
}
.modal-overlay.show { display: flex; }
.modal {
    background: #111530;
    border: 1px solid rgba(102,126,234,0.2);
    border-radius: 16px;
    padding: 32px;
    max-width: 500px;
    width: 90%;
    max-height: 80vh;
    overflow-y: auto;
}
.modal h2 { color: #fff; margin-bottom: 20px; font-size: 20px; }
.modal .form-group { margin-bottom: 16px; }
.modal .form-group label {
    display: block;
    font-size: 13px;
    color: #888;
    margin-bottom: 6px;
}
.modal .form-group input, .modal .form-group select {
    width: 100%;
    padding: 10px 14px;
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 8px;
    color: #fff;
    font-size: 14px;
}

/* 分页 */
.pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 24px;
}
.pagination a, .pagination span {
    padding: 8px 14px;
    border-radius: 8px;
    font-size: 14px;
    text-decoration: none;
}
.pagination a { background: rgba(102,126,234,0.1); color: #667eea; }
.pagination a:hover { background: rgba(102,126,234,0.2); }
.pagination .current { background: #667eea; color: #fff; }

/* 卡密列表 */
.card-key-cell { font-family: monospace; color: #a78bfa; }
.copy-btn {
    background: none;
    border: none;
    color: #667eea;
    cursor: pointer;
    font-size: 12px;
    margin-left: 6px;
}
.copy-btn:hover { color: #a78bfa; }

/* 导出按钮 */
.btn-export {
    padding: 10px 20px;
    background: rgba(76,175,80,0.15);
    color: #4caf50;
    border: 1px solid rgba(76,175,80,0.3);
    border-radius: 8px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s;
}
.btn-export:hover { background: rgba(76,175,80,0.25); }

/* 日志 */
.log-item {
    padding: 12px 16px;
    border-bottom: 1px solid rgba(255,255,255,0.03);
    font-size: 13px;
    color: #888;
}
.log-item:hover { background: rgba(102,126,234,0.03); }

/* 提示 */
.toast {
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 14px 24px;
    border-radius: 10px;
    font-size: 14px;
    z-index: 2000;
    animation: slideIn 0.3s ease;
    display: none;
}
.toast.show { display: block; }
.toast.success { background: #4caf50; color: #fff; }
.toast.error { background: #f44336; color: #fff; }
@keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }
</style>
</head>
<body>
<div class="layout">
    <!-- 侧边栏 -->
    <aside class="sidebar">
        <div class="logo">
            🔐 管理后台
            <small>● 已登录</small>
        </div>
        <button class="nav-item active" onclick="showSection('dashboard', this)">
            <span class="icon">📊</span> 仪表盘
        </button>
        <button class="nav-item" onclick="showSection('cards', this)">
            <span class="icon">🎫</span> 卡密管理
        </button>
        <button class="nav-item" onclick="showSection('generate', this)">
            <span class="icon">➕</span> 生成卡密
        </button>
        <button class="nav-item" onclick="showSection('orders', this)">
            <span class="icon">📋</span> 订单管理
        </button>
        <button class="nav-item" onclick="showSection('packages', this)">
            <span class="icon">📦</span> 套餐管理
        </button>
        <button class="nav-item" onclick="showSection('logs', this)">
            <span class="icon">📜</span> 激活日志
        </button>
        <button class="nav-item" onclick="showSection('settings', this)">
            <span class="icon">⚙️</span> 系统设置
        </button>
        
        <div style="position:absolute;bottom:24px;left:24px;right:24px;">
            <div style="font-size:12px;color:#444;margin-bottom:8px">
                登录身份：<?php echo Security::escape($_SESSION['admin_username']); ?>
            </div>
            <a href="logout.php" class="btn-sm btn-danger" style="display:block;text-align:center;text-decoration:none;">退出登录</a>
        </div>
    </aside>

    <!-- 主内容 -->
    <div class="main">
        <!-- 仪表盘 -->
        <div class="content-section active" id="section-dashboard">
            <div class="top-bar">
                <h1>仪表盘</h1>
                <div class="user-info">
                    <span>👤 <?php echo Security::escape($_SESSION['admin_username']); ?></span>
                </div>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="label">卡密总数</div>
                    <div class="value blue"><?php echo $stats['total']; ?></div>
                </div>
                <div class="stat-card">
                    <div class="label">未使用</div>
                    <div class="value orange"><?php echo $stats['unused']; ?></div>
                </div>
                <div class="stat-card">
                    <div class="label">已激活</div>
                    <div class="value green"><?php echo $stats['activated']; ?></div>
                </div>
                <div class="stat-card">
                    <div class="label">已过期</div>
                    <div class="value red"><?php echo $stats['expired']; ?></div>
                </div>
                <div class="stat-card">
                    <div class="label">今日激活</div>
                    <div class="value purple"><?php echo $stats['today_activated']; ?></div>
                </div>
                <div class="stat-card">
                    <div class="label">已售总额</div>
                    <div class="value green">¥<?php echo number_format($stats['total_amount'], 2); ?></div>
                </div>
            </div>
            
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
                <div class="stat-card">
                    <div class="label" style="margin-bottom:16px">快捷操作</div>
                    <div style="display:flex;flex-direction:column;gap:10px">
                        <button class="btn-primary" onclick="showSection('generate', document.querySelector('.nav-item:nth-child(3)'))">批量生成卡密</button>
                        <button class="btn-export" onclick="exportCards()">导出全部卡密</button>
                        <button class="btn-export" onclick="showSection('orders', document.querySelector('.nav-item:nth-child(5)'))">查看最新订单</button>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="label" style="margin-bottom:16px">系统信息</div>
                    <div style="font-size:13px;color:#888;line-height:2">
                        <p>PHP 版本：<?php echo PHP_VERSION; ?></p>
                        <p>系统版本：v<?php echo APP_VERSION; ?></p>
                        <p>数据库：SQLite3</p>
                        <p>服务器时间：<?php echo date('Y-m-d H:i:s'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- 卡密管理 -->
        <div class="content-section" id="section-cards">
            <div class="top-bar">
                <h1>卡密管理</h1>
                <div style="display:flex;gap:10px">
                    <button class="btn-export" onclick="exportCards()">📥 导出卡密</button>
                    <button class="btn-primary" onclick="showSection('generate', document.querySelector('.nav-item:nth-child(3)'))">➕ 生成新卡密</button>
                </div>
            </div>
            
            <div class="toolbar">
                <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
                    <select name="status" onchange="this.form.submit()">
                        <option value="-1" <?php echo $status==-1?'selected':''; ?>>全部状态</option>
                        <option value="0" <?php echo $status==0?'selected':''; ?>>未使用</option>
                        <option value="1" <?php echo $status==1?'selected':''; ?>>已激活</option>
                        <option value="2" <?php echo $status==2?'selected':''; ?>>已过期</option>
                        <option value="3" <?php echo $status==3?'selected':''; ?>>已禁用</option>
                    </select>
                    <input type="text" name="search" placeholder="搜索卡号/批次号" value="<?php echo Security::escape($search); ?>">
                    <button type="submit" class="btn-primary">搜索</button>
                </form>
            </div>
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>卡号</th>
                        <th>卡密</th>
                        <th>额度</th>
                        <th>有效期</th>
                        <th>状态</th>
                        <th>批次</th>
                        <th>创建时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($cardsData['data'] as $card): ?>
                    <tr>
                        <td><?php echo $card['id']; ?></td>
                        <td class="card-key-cell">
                            <?php echo Security::escape($card['card_key']); ?>
                            <button class="copy-btn" onclick="copyText('<?php echo $card['card_key']; ?>')">复制</button>
                        </td>
                        <td>
                            <span style="font-family:monospace;color:#666">••••••••••••</span>
                            <button class="copy-btn" onclick="copyText('<?php echo $card['card_secret']; ?>')">复制</button>
                        </td>
                        <td>¥<?php echo number_format($card['amount'], 2); ?></td>
                        <td><?php echo $card['duration']; ?>天</td>
                        <td>
                            <?php
                            $statusMap = [0=>'未使用',1=>'已激活',2=>'已过期',3=>'已禁用'];
                            $statusClass = 'status-'.$card['status'];
                            echo '<span class="status-badge '.$statusClass.'">'.$statusMap[$card['status']].'</span>';
                            ?>
                        </td>
                        <td style="font-size:12px;color:#666"><?php echo Security::escape($card['batch_no']); ?></td>
                        <td style="font-size:12px;color:#666"><?php echo date('Y-m-d H:i', $card['created_at']); ?></td>
                        <td>
                            <?php if ($card['status'] != 3): ?>
                            <button class="btn-sm btn-danger" onclick="disableCard(<?php echo $card['id']; ?>)">禁用</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($cardsData['data'])): ?>
                    <tr><td colspan="9" style="text-align:center;padding:40px;color:#555">暂无数据</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            
            <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?status=<?php echo $status; ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page-1; ?>">← 上一页</a>
                <?php endif; ?>
                <span class="current"><?php echo $page; ?> / <?php echo $totalPages; ?></span>
                <?php if ($page < $totalPages): ?>
                    <a href="?status=<?php echo $status; ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page+1; ?>">下一页 →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- 生成卡密 -->
        <div class="content-section" id="section-generate">
            <div class="top-bar">
                <h1>批量生成卡密</h1>
            </div>
            
            <div class="modal" style="max-width:480px;margin:0 auto;display:block">
                <h2>生成配置</h2>
                <form id="genForm">
                    <div class="form-group">
                        <label>生成数量</label>
                        <input type="number" name="count" min="1" max="1000" value="10" required>
                    </div>
                    <div class="form-group">
                        <label>授权额度 (¥)</label>
                        <input type="number" name="amount" min="0" step="0.01" value="100" required>
                    </div>
                    <div class="form-group">
                        <label>有效期 (天)</label>
                        <input type="number" name="duration" min="1" max="3650" value="30" required>
                    </div>
                    <div class="form-group">
                        <label>备注</label>
                        <input type="text" name="remark" placeholder="可选">
                    </div>
                    <button type="submit" class="btn-primary" style="width:100%;padding:14px">生成卡密</button>
                </form>
            </div>
            
            <div id="genResult" style="display:none;margin-top:24px">
                <div class="modal" style="max-width:600px;margin:0 auto;display:block">
                    <h2>✅ 生成成功</h2>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
                        <span style="font-size:14px;color:#888">批次号：<span id="batchNo" style="color:#a78bfa"></span></span>
                        <button class="btn-export" onclick="copyAllCards()">复制全部</button>
                    </div>
                    <div id="genCardsList" style="max-height:400px;overflow-y:auto"></div>
                </div>
            </div>
        </div>

        <!-- 订单管理 -->
        <div class="content-section" id="section-orders">
            <div class="top-bar">
                <h1>订单管理</h1>
            </div>
            
            <?php
            $ordersData = OrderManager::getOrders(1, 50, -1);
            ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>订单号</th>
                        <th>金额</th>
                        <th>状态</th>
                        <th>支付方式</th>
                        <th>卡号</th>
                        <th>联系方式</th>
                        <th>创建时间</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($ordersData['data'] as $order): ?>
                    <tr>
                        <td style="font-family:monospace;font-size:13px"><?php echo Security::escape($order['order_no']); ?></td>
                        <td>¥<?php echo number_format($order['amount'], 2); ?></td>
                        <td>
                            <span class="status-badge <?php echo $order['status']==1?'status-1':'status-0'; ?>">
                                <?php echo $order['status']==1?'已完成':'待支付'; ?>
                            </span>
                        </td>
                        <td style="font-size:13px"><?php echo Security::escape($order['payment_method']); ?></td>
                        <td style="font-size:12px;color:#a78bfa"><?php echo Security::escape($order['card_key'] ?? '-'); ?></td>
                        <td style="font-size:12px"><?php echo Security::escape($order['contact_info']); ?></td>
                        <td style="font-size:12px;color:#666"><?php echo date('Y-m-d H:i', $order['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($ordersData['data'])): ?>
                    <tr><td colspan="7" style="text-align:center;padding:40px;color:#555">暂无订单</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- 套餐管理 -->
        <div class="content-section" id="section-packages">
            <div class="top-bar">
                <h1>套餐管理</h1>
                <button class="btn-primary" onclick="showAddPackage()">➕ 添加套餐</button>
            </div>
            
            <?php $packages = $db->fetchAll("SELECT * FROM packages ORDER BY price ASC"); ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>名称</th>
                        <th>额度</th>
                        <th>有效期</th>
                        <th>售价</th>
                        <th>库存</th>
                        <th>状态</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($packages as $pkg): ?>
                    <tr>
                        <td><?php echo $pkg['id']; ?></td>
                        <td><?php echo Security::escape($pkg['name']); ?></td>
                        <td>¥<?php echo number_format($pkg['amount'], 2); ?></td>
                        <td><?php echo $pkg['duration']; ?>天</td>
                        <td>¥<?php echo number_format($pkg['price'], 2); ?></td>
                        <td><?php echo $pkg['stock']; ?></td>
                        <td>
                            <span class="status-badge <?php echo $pkg['status']?'status-1':'status-3'; ?>">
                                <?php echo $pkg['status']?'启用':'禁用'; ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn-sm btn-danger" onclick="togglePackage(<?php echo $pkg['id']; ?>, <?php echo $pkg['status']?0:1; ?>)">
                                <?php echo $pkg['status']?'禁用':'启用'; ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($packages)): ?>
                    <tr><td colspan="8" style="text-align:center;padding:40px;color:#555">暂无套餐，请添加</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            
            <!-- 添加套餐表单 -->
            <div class="modal" id="addPackageModal" style="max-width:480px;margin:24px auto;display:none">
                <h2>添加套餐</h2>
                <form id="pkgForm">
                    <div class="form-group">
                        <label>套餐名称</label>
                        <input type="text" name="name" placeholder="如：月卡套餐" required>
                    </div>
                    <div class="form-group">
                        <label>授权额度 (¥)</label>
                        <input type="number" name="amount" min="0" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>有效期 (天)</label>
                        <input type="number" name="duration" min="1" value="30" required>
                    </div>
                    <div class="form-group">
                        <label>售价 (¥)</label>
                        <input type="number" name="price" min="0" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>库存数量</label>
                        <input type="number" name="stock" min="0" value="0">
                    </div>
                    <button type="submit" class="btn-primary" style="width:100%;padding:14px">保存套餐</button>
                </form>
            </div>
        </div>

        <!-- 激活日志 -->
        <div class="content-section" id="section-logs">
            <div class="top-bar">
                <h1>激活日志</h1>
            </div>
            
            <?php
            $logs = $db->fetchAll("SELECT al.*, c.card_key FROM activation_logs al 
                                   LEFT JOIN cards c ON al.card_id = c.id 
                                   ORDER BY al.id DESC LIMIT 100");
            ?>
            <div style="background:linear-gradient(145deg,#111530,#0f1229);border-radius:12px;border:1px solid rgba(102,126,234,0.1);max-height:600px;overflow-y:auto">
                <?php foreach ($logs as $log): ?>
                <div class="log-item">
                    <span style="color:#a78bfa;font-family:monospace"><?php echo Security::escape($log['card_key']); ?></span>
                    | 设备: <?php echo Security::escape($log['device_id']); ?>
                    | IP: <?php echo Security::escape($log['ip']); ?>
                    | 时间: <?php echo date('Y-m-d H:i:s', $log['created_at']); ?>
                </div>
                <?php endforeach; ?>
                <?php if (empty($logs)): ?>
                    <div class="log-item" style="text-align:center;color:#555">暂无激活记录</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 系统设置 -->
        <div class="content-section" id="section-settings">
            <div class="top-bar">
                <h1>系统设置</h1>
            </div>
            
            <div class="modal" style="max-width:500px;margin:0 auto;display:block">
                <h2>修改管理员密码</h2>
                <form id="pwdForm">
                    <div class="form-group">
                        <label>当前密码</label>
                        <input type="password" name="old_password" required>
                    </div>
                    <div class="form-group">
                        <label>新密码</label>
                        <input type="password" name="new_password" minlength="8" required>
                    </div>
                    <div class="form-group">
                        <label>确认新密码</label>
                        <input type="password" name="new_password2" minlength="8" required>
                    </div>
                    <button type="submit" class="btn-primary" style="width:100%;padding:14px">更新密码</button>
                </form>
            </div>
            
            <div class="modal" style="max-width:500px;margin:24px auto;display:block">
                <h2>安全信息</h2>
                <div style="font-size:13px;color:#888;line-height:2.5">
                    <p>后台路径：<code style="color:#4caf50"><?php echo ADMIN_PATH; ?></code></p>
                    <p>APP_SECRET：<code style="color:#666"><?php echo substr(APP_SECRET, 0, 16); ?>...</code></p>
                    <p>数据库：SQLite3 (data/cards.db)</p>
                    <p style="color:#f44336;margin-top:12px">⚠️ 请妥善保管后台路径，切勿泄露给非授权人员</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Toast -->
<div class="toast" id="toast"></div>

<script>
var CSRF_TOKEN = '<?php echo $csrfToken; ?>';

function showSection(name, btn) {
    document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById('section-' + name).classList.add('active');
    if (btn) btn.classList.add('active');
}

function showToast(msg, type) {
    var toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.className = 'toast show ' + type;
    setTimeout(function() { toast.classList.remove('show'); }, 3000);
}

function copyText(text) {
    navigator.clipboard.writeText(text).then(function() {
        showToast('已复制: ' + text, 'success');
    }, function() {
        // fallback
        var ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('已复制', 'success');
    });
}

// 生成卡密
document.getElementById('genForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('csrf_token', CSRF_TOKEN);
    
    var btn = this.querySelector('button[type=submit]');
    btn.disabled = true;
    btn.textContent = '生成中...';
    
    fetch('api.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(res => {
        btn.disabled = false;
        btn.textContent = '生成卡密';
        
        if (res.success) {
            document.getElementById('genResult').style.display = 'block';
            document.getElementById('batchNo').textContent = res.batch_no;
            
            var html = '';
            res.cards.forEach(function(c) {
                html += '<div style="padding:10px;border-bottom:1px solid rgba(255,255,255,0.03);font-size:13px">' +
                    '<span style="color:#a78bfa;font-family:monospace">' + c.key + '</span>' +
                    ' | <span style="color:#888;font-family:monospace">' + c.secret + '</span>' +
                    ' | ¥' + c.amount + ' | ' + c.duration + '天' +
                    '</div>';
            });
            document.getElementById('genCardsList').innerHTML = html;
            showToast('成功生成 ' + res.count + ' 张卡密', 'success');
            this.reset();
        } else {
            showToast(res.msg || '生成失败', 'error');
        }
    });
});

function copyAllCards() {
    var text = '';
    document.querySelectorAll('#genCardsList div').forEach(function(div) {
        text += div.textContent + '\n';
    });
    copyText(text);
}

function disableCard(id) {
    if (!confirm('确定禁用这张卡密吗？')) return;
    
    var fd = new FormData();
    fd.append('action', 'disable_card');
    fd.append('card_id', id);
    fd.append('csrf_token', CSRF_TOKEN);
    
    fetch('api.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            showToast('已禁用', 'success');
            setTimeout(() => location.reload(), 1000);
        }
    });
}

function exportCards() {
    showToast('正在导出...', 'success');
    window.location.href = 'api.php?action=export&csrf_token=' + CSRF_TOKEN;
}

function showAddPackage() {
    document.getElementById('addPackageModal').style.display = 'block';
}

document.getElementById('pkgForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action', 'add_package');
    fd.append('csrf_token', CSRF_TOKEN);
    
    fetch('api.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            showToast('套餐添加成功', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(res.msg || '添加失败', 'error');
        }
    });
});

function togglePackage(id, newStatus) {
    var fd = new FormData();
    fd.append('action', 'toggle_package');
    fd.append('package_id', id);
    fd.append('status', newStatus);
    fd.append('csrf_token', CSRF_TOKEN);
    
    fetch('api.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            showToast('更新成功', 'success');
            setTimeout(() => location.reload(), 1000);
        }
    });
}

// 修改密码
document.getElementById('pwdForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action', 'change_password');
    fd.append('csrf_token', CSRF_TOKEN);
    
    fetch('api.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            showToast('密码修改成功', 'success');
            this.reset();
        } else {
            showToast(res.msg || '修改失败', 'error');
        }
    });
});
</script>
</body>
</html>
