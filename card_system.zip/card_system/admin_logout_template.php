<?php
/**
 * 后台登出
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/Auth.php';

Auth::adminLogout();
header('Location: login.php');
exit;
