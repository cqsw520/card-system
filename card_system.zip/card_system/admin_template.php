<?php
/**
 * 后台登录页面
 * 路径在安装时随机生成，例如 /admin_a8f3b2c1d4e5/
 * 前台用户无法获知此路径
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db/init.php';
require_once __DIR__ . '/../lib/Security.php';
require_once __DIR__ . '/../lib/Auth.php';

// 如果已登录，跳转到后台首页
if (Auth::isAdminLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $result = Auth::adminLogin($username, $password);
    if ($result['success']) {
        header('Location: index.php');
        exit;
    } else {
        $error = $result['msg'];
    }
}

$csrfToken = Security::generateCsrfToken();

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>管理后台 - 登录</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #0a0e27 0%, #1a1a3e 50%, #0d1137 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}
.login-box {
    background: rgba(17, 21, 48, 0.95);
    border: 1px solid rgba(102, 126, 234, 0.2);
    border-radius: 20px;
    padding: 48px;
    width: 400px;
    max-width: 90vw;
    box-shadow: 0 20px 60px rgba(0,0,0,0.5);
}
.login-box h1 {
    font-size: 24px;
    color: #fff;
    margin-bottom: 8px;
    text-align: center;
}
.login-box .subtitle {
    color: #666;
    font-size: 13px;
    text-align: center;
    margin-bottom: 32px;
}
.form-group { margin-bottom: 20px; }
.form-group label {
    display: block;
    font-size: 13px;
    color: #888;
    margin-bottom: 6px;
}
.form-group input {
    width: 100%;
    padding: 12px 16px;
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 10px;
    color: #fff;
    font-size: 15px;
    transition: border-color 0.3s;
}
.form-group input:focus {
    outline: none;
    border-color: #667eea;
}
.btn {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}
.btn-primary {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
}
.btn-primary:hover { opacity: 0.9; }
.alert {
    padding: 12px 16px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-size: 14px;
}
.alert-error { background: rgba(244,67,54,0.1); color: #f44336; border: 1px solid rgba(244,67,54,0.3); }
.security-badge {
    text-align: center;
    margin-top: 24px;
    font-size: 12px;
    color: #444;
}
.security-badge span { color: #4caf50; }
</style>
</head>
<body>
<div class="login-box">
    <h1>🔐 管理后台</h1>
    <p class="subtitle">卡密授权管理系统</p>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo Security::escape($error); ?></div>
    <?php endif; ?>
    
    <form method="POST" id="loginForm">
        <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
        <div class="form-group">
            <label>管理员账号</label>
            <input type="text" name="username" placeholder="请输入管理员用户名" required autofocus>
        </div>
        <div class="form-group">
            <label>管理员密码</label>
            <input type="password" name="password" placeholder="请输入密码" required>
        </div>
        <button type="submit" class="btn btn-primary" id="loginBtn">登 录</button>
    </form>
    
    <div class="security-badge">
        <span>●</span> 安全连接 | 登录尝试受IP限制
    </div>
</div>
<script>
document.getElementById('loginForm').addEventListener('submit', function() {
    var btn = document.getElementById('loginBtn');
    btn.disabled = true;
    btn.textContent = '登录中...';
});
</script>
</body>
</html>
