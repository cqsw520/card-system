<?php
/**
 * 系统配置文件
 * 安装后自动生成，请勿手动修改
 */

// 安全密钥（安装时随机生成）
define('APP_SECRET', 'a8f3b2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0');
define('ADMIN_PATH', 'admin_3da296cf4cd3');
define('APP_VERSION', '1.0.0');

// 数据库路径（绝对路径）
define('DB_PATH', '/tmp/card_system_data/cards.db');

// 会话配置
define('SESSION_LIFETIME', 7200); // 2小时
define('CSRF_TOKEN_NAME', 'csrf_token');

// 卡密配置
define('CARD_KEY_LENGTH', 16);    // 卡号长度
define('CARD_SECRET_LENGTH', 12);  // 卡密长度
define('DEFAULT_DURATION', 30);   // 默认有效期(天)

// 安全配置
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCK_TIME', 900); // 15分钟锁定

// 调试模式（生产环境设为false）
define('DEBUG_MODE', true);

// 自动加载
spl_autoload_register(function($class) {
    $paths = [
        '/data/workspace/card_system/db/',
        '/data/workspace/card_system/lib/',
    ];
    foreach ($paths as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});
