<?php
/**
 * 前台首页
 * 用户可购买卡密、激活卡密、查询卡密状态
 * 绝对无法访问后台功能
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db/init.php';
require_once __DIR__ . '/lib/Security.php';
require_once __DIR__ . '/lib/CardManager.php';
require_once __DIR__ . '/lib/OrderManager.php';

// 处理API请求
if (isset($_GET['api'])) {
    header('Content-Type: application/json; charset=utf-8');
    
    $action = $_POST['action'] ?? $_GET['action'] ?? '';
    
    switch ($action) {
        case 'activate':
            $key = $_POST['card_key'] ?? '';
            $secret = $_POST['card_secret'] ?? '';
            $deviceId = $_POST['device_id'] ?? '';
            echo json_encode(CardManager::activate($key, $secret, $deviceId));
            exit;
            
        case 'query':
            $key = $_POST['card_key'] ?? '';
            $secret = $_POST['card_secret'] ?? '';
            echo json_encode(CardManager::queryStatus($key, $secret));
            exit;
            
        case 'create_order':
            $amount = floatval($_POST['amount'] ?? 0);
            $method = $_POST['payment_method'] ?? 'manual';
            $contact = $_POST['contact'] ?? '';
            echo json_encode(OrderManager::createOrder($amount, $method, $contact));
            exit;
            
        case 'get_packages':
            $db = Database::getInstance();
            $packages = $db->fetchAll("SELECT * FROM packages WHERE status = 1 ORDER BY price ASC");
            echo json_encode(['success' => true, 'data' => $packages]);
            exit;
    }
    
    echo json_encode(['success' => false, 'msg' => '未知操作']);
    exit;
}

// 前台页面
$db = Database::getInstance();
$packages = $db->fetchAll("SELECT * FROM packages WHERE status = 1 ORDER BY price ASC") ?: [
    ['id' => 1, 'name' => '月卡套餐', 'amount' => 100, 'duration' => 30, 'price' => 99.99],
    ['id' => 2, 'name' => '季卡套餐', 'amount' => 300, 'duration' => 90, 'price' => 269.99],
    ['id' => 3, 'name' => '年卡套餐', 'amount' => 1200, 'duration' => 365, 'price' => 899.99],
];

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>卡密授权中心</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
    background: #0a0e27;
    color: #e0e0e0;
    min-height: 100vh;
}
.nav {
    background: rgba(15, 20, 50, 0.9);
    backdrop-filter: blur(10px);
    padding: 16px 32px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid rgba(255,255,255,0.05);
    position: sticky;
    top: 0;
    z-index: 100;
}
.nav .logo {
    font-size: 20px;
    font-weight: 700;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.nav-links { display: flex; gap: 24px; }
.nav-links a {
    color: #888;
    text-decoration: none;
    font-size: 14px;
    transition: color 0.3s;
    cursor: pointer;
}
.nav-links a:hover, .nav-links a.active { color: #667eea; }
.container { max-width: 1100px; margin: 0 auto; padding: 32px 20px; }
.section { display: none; }
.section.active { display: block; }
.section-title {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 8px;
    color: #fff;
}
.section-desc {
    color: #666;
    font-size: 14px;
    margin-bottom: 32px;
}

/* 套餐卡片 */
.packages-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}
.package-card {
    background: linear-gradient(145deg, #111530, #0f1229);
    border: 1px solid rgba(102, 126, 234, 0.15);
    border-radius: 16px;
    padding: 32px 24px;
    text-align: center;
    transition: all 0.3s;
    position: relative;
    overflow: hidden;
}
.package-card:hover {
    border-color: rgba(102, 126, 234, 0.5);
    transform: translateY(-4px);
    box-shadow: 0 12px 40px rgba(102, 126, 234, 0.15);
}
.package-card.popular {
    border-color: rgba(102, 126, 234, 0.4);
}
.package-card.popular::before {
    content: '热门';
    position: absolute;
    top: 12px;
    right: 12px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
    font-size: 11px;
    padding: 2px 10px;
    border-radius: 10px;
}
.pkg-name {
    font-size: 18px;
    color: #fff;
    margin-bottom: 8px;
    font-weight: 600;
}
.pkg-price {
    font-size: 36px;
    font-weight: 800;
    background: linear-gradient(135deg, #667eea, #a78bfa);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin: 16px 0;
}
.pkg-price small {
    font-size: 14px;
    -webkit-text-fill-color: #666;
}
.pkg-features {
    list-style: none;
    margin: 20px 0;
    text-align: left;
}
.pkg-features li {
    padding: 6px 0;
    color: #888;
    font-size: 14px;
}
.pkg-features li::before { content: '✓ '; color: #4caf50; font-weight: bold; }
.btn {
    display: inline-block;
    padding: 12px 32px;
    border: none;
    border-radius: 10px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
}
.btn-primary {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
    width: 100%;
}
.btn-primary:hover { opacity: 0.9; transform: scale(1.02); }
.btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }

/* 表单 */
.form-card {
    background: linear-gradient(145deg, #111530, #0f1229);
    border: 1px solid rgba(102, 126, 234, 0.15);
    border-radius: 16px;
    padding: 32px;
    max-width: 480px;
    margin: 0 auto;
}
.form-group { margin-bottom: 20px; }
.form-group label {
    display: block;
    font-size: 14px;
    color: #888;
    margin-bottom: 8px;
}
.form-group input {
    width: 100%;
    padding: 12px 16px;
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 10px;
    color: #fff;
    font-size: 15px;
    transition: border-color 0.3s;
}
.form-group input:focus {
    outline: none;
    border-color: #667eea;
}
.form-group input::placeholder { color: #444; }

/* 结果展示 */
.result-box {
    margin-top: 24px;
    padding: 20px;
    border-radius: 12px;
    display: none;
}
.result-box.show { display: block; }
.result-box.success {
    background: rgba(76, 175, 80, 0.1);
    border: 1px solid rgba(76, 175, 80, 0.3);
}
.result-box.error {
    background: rgba(244, 67, 54, 0.1);
    border: 1px solid rgba(244, 67, 54, 0.3);
}
.result-box.info {
    background: rgba(102, 126, 234, 0.1);
    border: 1px solid rgba(102, 126, 234, 0.3);
}
.result-box h3 { margin-bottom: 12px; font-size: 16px; }
.result-box p { font-size: 14px; line-height: 1.8; color: #aaa; }
.result-box .highlight {
    color: #4caf50;
    font-weight: 600;
    font-size: 16px;
}

/* 模态框 */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.7);
    z-index: 1000;
    align-items: center;
    justify-content: center;
}
.modal-overlay.show { display: flex; }
.modal {
    background: #111530;
    border: 1px solid rgba(102, 126, 234, 0.2);
    border-radius: 16px;
    padding: 32px;
    max-width: 420px;
    width: 90%;
}
.modal h2 { color: #fff; margin-bottom: 16px; font-size: 20px; }
.modal p { color: #888; font-size: 14px; margin-bottom: 20px; }
.modal .btn { margin-top: 8px; }

/* 页脚 */
.footer {
    text-align: center;
    padding: 32px;
    color: #444;
    font-size: 13px;
    border-top: 1px solid rgba(255,255,255,0.03);
}

/* 动画 */
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
.section.active { animation: fadeIn 0.4s ease; }

/* 加载动画 */
.loading {
    display: inline-block;
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    vertical-align: middle;
    margin-right: 8px;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
</head>
<body>

<nav class="nav">
    <div class="logo">🔐 卡密授权中心</div>
    <div class="nav-links">
        <a onclick="showSection('buy')" class="active" id="nav-buy">购买卡密</a>
        <a onclick="showSection('activate')" id="nav-activate">激活卡密</a>
        <a onclick="showSection('query')" id="nav-query">查询状态</a>
    </div>
</nav>

<div class="container">
    <!-- 购买卡密 -->
    <div class="section active" id="section-buy">
        <h1 class="section-title">选择套餐</h1>
        <p class="section-desc">购买后自动生成卡密，请妥善保管</p>
        
        <div class="packages-grid" id="packagesGrid">
            <?php foreach ($packages as $i => $pkg): ?>
            <div class="package-card <?php echo $i === 1 ? 'popular' : ''; ?>">
                <div class="pkg-name"><?php echo Security::escape($pkg['name']); ?></div>
                <div class="pkg-price">¥<?php echo number_format($pkg['price'], 2); ?> <small>/ <?php echo $pkg['duration']; ?>天</small></div>
                <ul class="pkg-features">
                    <li>授权额度 ¥<?php echo number_format($pkg['amount'], 2); ?></li>
                    <li>有效期 <?php echo $pkg['duration']; ?> 天</li>
                    <li>支持多设备切换</li>
                    <li>7×24小时技术支持</li>
                </ul>
                <button class="btn btn-primary" onclick="buyPackage(<?php echo $pkg['id']; ?>, '<?php echo Security::escape($pkg['name']); ?>', <?php echo $pkg['price']; ?>)">
                    立即购买
                </button>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- 激活卡密 -->
    <div class="section" id="section-activate">
        <h1 class="section-title">激活卡密</h1>
        <p class="section-desc">输入您的卡号和卡密进行激活</p>
        
        <div class="form-card">
            <div class="form-group">
                <label>卡号</label>
                <input type="text" id="act-key" placeholder="XXXX-XXXX-XXXX-XXXX" style="text-transform:uppercase" maxlength="19">
            </div>
            <div class="form-group">
                <label>卡密</label>
                <input type="password" id="act-secret" placeholder="请输入卡密">
            </div>
            <div class="form-group">
                <label>设备标识（可选）</label>
                <input type="text" id="act-device" placeholder="留空自动获取">
            </div>
            <button class="btn btn-primary" onclick="doActivate()">立即激活</button>
            
            <div class="result-box" id="act-result"></div>
        </div>
    </div>
    
    <!-- 查询状态 -->
    <div class="section" id="section-query">
        <h1 class="section-title">查询卡密状态</h1>
        <p class="section-desc">查看卡密的使用情况和有效期</p>
        
        <div class="form-card">
            <div class="form-group">
                <label>卡号</label>
                <input type="text" id="qry-key" placeholder="XXXX-XXXX-XXXX-XXXX" style="text-transform:uppercase" maxlength="19">
            </div>
            <div class="form-group">
                <label>卡密</label>
                <input type="password" id="qry-secret" placeholder="请输入卡密">
            </div>
            <button class="btn btn-primary" onclick="doQuery()">查询状态</button>
            
            <div class="result-box" id="qry-result"></div>
        </div>
    </div>
</div>

<!-- 购买确认模态框 -->
<div class="modal-overlay" id="buyModal">
    <div class="modal">
        <h2>确认购买</h2>
        <p id="buyModalText"></p>
        <div class="form-group">
            <label>联系方式（用于接收卡密）</label>
            <input type="text" id="buy-contact" placeholder="邮箱或手机号">
        </div>
        <button class="btn btn-primary" onclick="confirmBuy()" id="buyBtn">确认支付</button>
    </div>
</div>

<footer class="footer">
    © 2026 卡密授权中心 | 安全可靠 | 仅供授权使用
</footer>

<script>
let selectedPackage = null;

function showSection(name) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
    
    document.getElementById('section-' + name).classList.add('active');
    document.getElementById('nav-' + name).classList.add('active');
}

function buyPackage(id, name, price) {
    selectedPackage = { id, name, price };
    document.getElementById('buyModalText').innerHTML = 
        '套餐：<strong style="color:#fff">' + name + '</strong><br>' +
        '金额：<strong style="color:#667eea">¥' + price.toFixed(2) + '</strong>';
    document.getElementById('buyModal').classList.add('show');
}

function confirmBuy() {
    var btn = document.getElementById('buyBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="loading"></span>处理中...';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '?api=1');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        var res = JSON.parse(xhr.responseText);
        btn.disabled = false;
        btn.innerHTML = '确认支付';
        
        if (res.success) {
            // 模拟支付成功，自动完成订单
            setTimeout(function() {
                completeOrder(res.order_no);
            }, 1500);
        } else {
            alert(res.msg || '创建订单失败');
        }
    };
    xhr.send('action=create_order&amount=' + selectedPackage.price + '&contact=' + 
             encodeURIComponent(document.getElementById('buy-contact').value));
}

function completeOrder(orderNo) {
    // 模拟支付完成，自动分配卡密
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '?api=1');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        var res = JSON.parse(xhr.responseText);
        document.getElementById('buyModal').classList.remove('show');
        
        if (res.success) {
            showSection('activate');
            document.getElementById('act-key').value = res.card_key;
            document.getElementById('act-secret').value = res.card_secret;
            
            var box = document.getElementById('act-result');
            box.className = 'result-box show success';
            box.innerHTML = '<h3>🎉 购买成功！</h3>' +
                '<p>卡号：<span class="highlight">' + res.card_key + '</span></p>' +
                '<p>卡密：<span class="highlight">' + res.card_secret + '</span></p>' +
                '<p style="margin-top:12px;color:#4caf50">卡密已自动填入，点击下方按钮激活</p>';
        }
    };
    xhr.send('action=complete_order&order_no=' + orderNo);
}

function doActivate() {
    var key = document.getElementById('act-key').value.trim();
    var secret = document.getElementById('act-secret').value.trim();
    var device = document.getElementById('act-device').value.trim();
    
    if (!key || !secret) {
        showResult('act-result', 'error', '请输入卡号和卡密');
        return;
    }
    
    var btn = event.target;
    btn.disabled = true;
    btn.innerHTML = '<span class="loading"></span>激活中...';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '?api=1');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        btn.disabled = false;
        btn.innerHTML = '立即激活';
        var res = JSON.parse(xhr.responseText);
        
        if (res.success) {
            var html = '<h3>✅ 激活成功！</h3>' +
                '<p>授权额度：<span class="highlight">¥' + res.data.amount + '</span></p>' +
                '<p>有效期：' + res.data.duration + ' 天</p>' +
                '<p>激活时间：' + res.data.activated_at + '</p>' +
                '<p>到期时间：<span class="highlight">' + res.data.expired_at + '</span></p>';
            showResult('act-result', 'success', '', html);
        } else {
            showResult('act-result', 'error', res.msg);
        }
    };
    xhr.send('action=activate&card_key=' + encodeURIComponent(key) + 
             '&card_secret=' + encodeURIComponent(secret) + 
             '&device_id=' + encodeURIComponent(device || 'web_user'));
}

function doQuery() {
    var key = document.getElementById('qry-key').value.trim();
    var secret = document.getElementById('qry-secret').value.trim();
    
    if (!key || !secret) {
        showResult('qry-result', 'error', '请输入卡号和卡密');
        return;
    }
    
    var btn = event.target;
    btn.disabled = true;
    btn.innerHTML = '<span class="loading"></span>查询中...';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '?api=1');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        btn.disabled = false;
        btn.innerHTML = '查询状态';
        var res = JSON.parse(xhr.responseText);
        
        if (res.success) {
            var d = res.data;
            var statusColor = d.status_code == 0 ? '#ff9800' : (d.status_code == 1 ? '#4caf50' : '#f44336');
            var html = '<h3>📋 卡密信息</h3>' +
                '<p>卡号：' + d.card_key + '</p>' +
                '<p>授权额度：¥' + d.amount + '</p>' +
                '<p>有效期：' + d.duration + ' 天</p>' +
                '<p>状态：<span style="color:' + statusColor + ';font-weight:bold">' + d.status + '</span></p>' +
                '<p>激活时间：' + d.activated_at + '</p>' +
                '<p>到期时间：' + d.expired_at + '</p>' +
                '<p>绑定设备：' + d.device_id + '</p>';
            showResult('qry-result', 'info', '', html);
        } else {
            showResult('qry-result', 'error', res.msg);
        }
    };
    xhr.send('action=query&card_key=' + encodeURIComponent(key) + 
             '&card_secret=' + encodeURIComponent(secret));
}

function showResult(id, type, msg, html) {
    var box = document.getElementById(id);
    box.className = 'result-box show ' + type;
    box.innerHTML = html || '<h3>' + (type === 'error' ? '❌ ' : '✅ ') + msg + '</h3>';
}

// 自动格式化卡号输入
document.getElementById('act-key').addEventListener('input', formatCardKey);
document.getElementById('qry-key').addEventListener('input', formatCardKey);

function formatCardKey(e) {
    var v = e.target.value.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    var parts = [];
    for (var i = 0; i < v.length && i < 16; i += 4) {
        parts.push(v.substr(i, 4));
    }
    e.target.value = parts.join('-');
}
</script>
</body>
</html>
