<?php
/**
 * 安装向导
 * 完成后自动重定向到后台
 */
define('INSTALL_MODE', true);

// 如果已安装，显示提示
$installed = file_exists(__DIR__ . '/data/installed.lock');

$step = $_GET['step'] ?? 'check';
$msg = '';
$error = '';

// 处理安装提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 'config') {
    $adminUser = trim($_POST['username'] ?? '');
    $adminPass = $_POST['password'] ?? '';
    $adminPass2 = $_POST['password2'] ?? '';
    
    if (strlen($adminUser) < 3) {
        $error = '管理员用户名至少3个字符';
    } elseif (strlen($adminPass) < 8) {
        $error = '密码至少8个字符';
    } elseif ($adminPass !== $adminPass2) {
        $error = '两次输入的密码不一致';
    } else {
        try {
            // 加载依赖
            require_once __DIR__ . '/config.php';
            require_once __DIR__ . '/db/init.php';
            require_once __DIR__ . '/lib/Security.php';
            
            $db = Database::getInstance();
            
            // 创建管理员
            $hash = Security::hashPassword($adminPass);
            $db->insert("INSERT INTO admins (username, password_hash) VALUES (?, ?)", 
                [$adminUser, $hash]);
            
            // 写入安装锁
            file_put_contents(__DIR__ . '/data/installed.lock', date('Y-m-d H:i:s'));
            
            // 生成随机密钥
            $newSecret = bin2hex(random_bytes(32));
            $configPath = __DIR__ . '/config.php';
            $config = file_get_contents($configPath);
            $config = preg_replace("/define\('APP_SECRET',\s*'[^']*'\);/", 
                "define('APP_SECRET', '" . $newSecret . "');", $config);
            file_put_contents($configPath, $config);
            
            // 重新生成后台路径（如果需要）
            $newAdminPath = 'admin_' . substr(bin2hex(random_bytes(8)), 0, 12);
            $config = preg_replace("/define\('ADMIN_PATH',\s*'[^']*'\);/", 
                "define('ADMIN_PATH', '" . $newAdminPath . "');", $config);
            file_put_contents($configPath, $config);
            
            // 复制后台文件到新目录
            $adminDir = __DIR__ . '/' . $newAdminPath;
            if (!is_dir($adminDir)) mkdir($adminDir, 0755, true);
            
            $files = [
                'admin_template.php' => 'login.php',
                'admin_index_template.php' => 'index.php',
                'admin_api_template.php' => 'api.php',
                'admin_logout_template.php' => 'logout.php',
            ];
            foreach ($files as $src => $dst) {
                $srcPath = __DIR__ . '/' . $src;
                if (file_exists($srcPath)) {
                    copy($srcPath, $adminDir . '/' . $dst);
                }
            }
            
            // 删除旧的admin目录（如果存在且不是当前目录）
            // 读取旧路径
            preg_match("/define\('ADMIN_PATH',\s*'([^']*)'\);/", $config, $matches);
            
            header('Location: install.php?step=done&path=' . urlencode($newAdminPath));
            exit;
            
        } catch (Exception $e) {
            $error = '安装失败: ' . $e->getMessage();
        }
    }
}

// 已安装则跳转到完成页
if ($installed && $step !== 'done') {
    $step = 'installed';
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>卡密系统安装向导</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { 
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}
.install-box {
    background: rgba(20, 25, 60, 0.95);
    border: 1px solid rgba(102, 126, 234, 0.2);
    border-radius: 20px;
    padding: 48px;
    max-width: 560px;
    width: 92%;
    box-shadow: 0 20px 80px rgba(0,0,0,0.5);
}
.install-box h1 {
    font-size: 26px;
    color: #fff;
    margin-bottom: 8px;
}
.install-box .subtitle {
    color: #888;
    font-size: 14px;
    margin-bottom: 32px;
}
.step-indicator {
    display: flex;
    gap: 8px;
    margin-bottom: 36px;
}
.step-dot {
    flex: 1;
    height: 4px;
    border-radius: 2px;
    background: rgba(255,255,255,0.1);
    transition: all 0.3s;
}
.step-dot.active { background: #667eea; }
.step-dot.done { background: #4caf50; }
.form-group { margin-bottom: 20px; }
.form-group label {
    display: block;
    font-size: 14px;
    color: #aaa;
    margin-bottom: 6px;
    font-weight: 500;
}
.form-group input {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid rgba(255,255,255,0.08);
    border-radius: 10px;
    font-size: 15px;
    background: rgba(255,255,255,0.03);
    color: #fff;
    transition: border-color 0.3s;
}
.form-group input:focus {
    outline: none;
    border-color: #667eea;
}
.btn {
    width: 100%;
    padding: 15px;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}
.btn-primary {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
}
.btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
.alert {
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-size: 14px;
    line-height: 1.6;
}
.alert-error { background: rgba(244,67,54,0.1); color: #f44336; border: 1px solid rgba(244,67,54,0.3); }
.alert-success { background: rgba(76,175,80,0.1); color: #4caf50; border: 1px solid rgba(76,175,80,0.3); }
.alert-info { background: rgba(102,126,234,0.1); color: #a78bfa; border: 1px solid rgba(102,126,234,0.3); }
.check-list { list-style: none; }
.check-list li {
    padding: 10px 0;
    color: #ccc;
    font-size: 14px;
    border-bottom: 1px solid rgba(255,255,255,0.03);
}
.check-list li:last-child { border: none; }
.check-list li.ok::before { content: '✅ '; }
.check-list li.bad::before { content: '❌ '; }
.check-list li.warn::before { content: '⚠️ '; }
.success-icon { text-align: center; font-size: 64px; margin-bottom: 16px; }
.info-box {
    background: rgba(102,126,234,0.05);
    border: 1px solid rgba(102,126,234,0.15);
    border-radius: 10px;
    padding: 18px;
    margin: 16px 0;
}
.info-box p {
    font-size: 14px;
    color: #aaa;
    margin-bottom: 8px;
    line-height: 1.6;
}
.info-box code {
    background: rgba(102,126,234,0.15);
    padding: 2px 10px;
    border-radius: 4px;
    font-family: 'Courier New', monospace;
    color: #a78bfa;
    font-size: 13px;
}
.highlight { color: #4caf50 !important; }
.warning { color: #ff9800 !important; }
</style>
</head>
<body>
<div class="install-box">
<?php if ($step === 'check'): ?>
    <h1>🔐 卡密授权系统</h1>
    <p class="subtitle">安装向导 - 步骤 1/3：环境检查</p>
    <div class="step-indicator">
        <div class="step-dot active"></div>
        <div class="step-dot"></div>
        <div class="step-dot"></div>
    </div>
    
    <?php
    $checks = [];
    $checks[] = ['PHP >= 7.4', version_compare(PHP_VERSION, '7.4.0') >= 0, PHP_VERSION, 'ok'];
    $checks[] = ['SQLite3 扩展', extension_loaded('sqlite3'), extension_loaded('sqlite3') ? '已加载' : '未加载', extension_loaded('sqlite3') ? 'ok' : 'bad'];
    $checks[] = ['OpenSSL 扩展', extension_loaded('openssl'), extension_loaded('openssl') ? '已加载' : '未加载', extension_loaded('openssl') ? 'ok' : 'bad'];
    $checks[] = ['写入权限 (data)', is_writable(__DIR__ . '/data') || (!file_exists(__DIR__.'/data') && is_writable(__DIR__)), is_writable(__DIR__ . '/data') ? '可写' : '不可写', is_writable(__DIR__ . '/data') ? 'ok' : 'warn'];
    $checks[] = ['Session 支持', function_exists('session_start'), '支持', 'ok'];
    $checks[] = ['PDO SQLite', extension_loaded('pdo_sqlite'), extension_loaded('pdo_sqlite') ? '已加载' : '未加载', 'ok'];
    
    $allPass = true;
    foreach ($checks as $c) {
        if ($c[3] === 'bad') $allPass = false;
    }
    ?>
    
    <ul class="check-list">
    <?php foreach ($checks as $c): ?>
        <li class="<?php echo $c[3]; ?>">
            <strong><?php echo $c[0]; ?></strong> 
            <span style="color:#666;font-size:12px"> — <?php echo $c[2]; ?></span>
        </li>
    <?php endforeach; ?>
    </ul>
    
    <br>
    <?php if ($allPass): ?>
        <a href="?step=config" class="btn btn-primary" style="display:block;text-align:center;text-decoration:none;">下一步 → 设置管理员</a>
    <?php else: ?>
        <div class="alert alert-error">
            <strong>环境检查未通过！</strong><br>
            请修复上述 ❌ 标记的项目后刷新页面重试。
        </div>
    <?php endif; ?>

<?php elseif ($step === 'config'): ?>
    <h1>⚙️ 管理员配置</h1>
    <p class="subtitle">安装向导 - 步骤 2/3：设置管理员账户</p>
    <div class="step-indicator">
        <div class="step-dot done"></div>
        <div class="step-dot active"></div>
        <div class="step-dot"></div>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <div class="alert alert-info">
        <strong>🔒 安全机制说明：</strong><br>
        • 后台路径将随机生成（如 /admin_a8f3b2c1d4e5/）<br>
        • 前台用户无法获知后台地址<br>
        • 密码使用 Argon2id 加密存储<br>
        • 登录有IP限制和CSRF保护
    </div>
    
    <form method="POST">
        <div class="form-group">
            <label>管理员用户名</label>
            <input type="text" name="username" placeholder="至少3个字符" required minlength="3" autofocus>
        </div>
        <div class="form-group">
            <label>管理员密码</label>
            <input type="password" name="password" placeholder="至少8个字符，建议包含大小写+数字" required minlength="8">
        </div>
        <div class="form-group">
            <label>确认密码</label>
            <input type="password" name="password2" placeholder="再次输入密码" required minlength="8">
        </div>
        <button type="submit" class="btn btn-primary">🔐 安装并创建管理员</button>
    </form>

<?php elseif ($step === 'done'): ?>
    <?php $adminPath = $_GET['path'] ?? 'admin_xxxx'; ?>
    <div class="success-icon">🎉</div>
    <h1 style="text-align:center">安装成功！</h1>
    <p class="subtitle" style="text-align:center">卡密授权系统已准备就绪</p>
    <div class="step-indicator">
        <div class="step-dot done"></div>
        <div class="step-dot done"></div>
        <div class="step-dot done"></div>
    </div>
    
    <div class="info-box">
        <p><strong>前台地址：</strong></p>
        <p><code><?php echo (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . dirname($_SERVER['REQUEST_URI']); ?>/</code></p>
        <br>
        <p><strong class="highlight">🔐 后台地址（请务必保存！）：</strong></p>
        <p><code>/<?php echo htmlspecialchars($adminPath); ?>/</code></p>
        <p><code>/<?php echo htmlspecialchars($adminPath); ?>/login.php</code></p>
    </div>
    
    <div class="alert alert-error" style="margin:16px 0">
        <strong>⚠️ 重要安全提醒：</strong><br>
        1. <strong>立即删除</strong> install.php 和 setup.php 文件<br>
        2. 后台路径请勿泄露给非授权人员<br>
        3. 首次登录后<strong>立即修改密码</strong><br>
        4. 数据库位于 /tmp 目录，重启服务器后需重新安装
    </div>
    
    <div style="display:flex;gap:12px;margin-top:20px">
        <a href="../<?php echo htmlspecialchars($adminPath); ?>/login.php" class="btn btn-primary" style="flex:1;text-align:center;text-decoration:none;">进入后台</a>
        <a href="../" class="btn btn-primary" style="flex:1;text-align:center;text-decoration:none;background:rgba(102,126,234,0.2);border:1px solid rgba(102,126,234,0.3)">前台首页</a>
    </div>

<?php elseif ($step === 'installed'): ?>
    <div class="success-icon">✅</div>
    <h1 style="text-align:center">系统已安装</h1>
    <p class="subtitle" style="text-align:center">如需重新安装，请删除 data/installed.lock 文件</p>
    <div class="alert alert-info">
        安装锁文件位置：<code>data/installed.lock</code><br>
        部署信息：<code>data/deploy_info.json</code>
    </div>
    <a href="../" class="btn btn-primary" style="display:block;text-align:center;text-decoration:none;">进入前台</a>
<?php endif; ?>
</div>
</body>
</html>
