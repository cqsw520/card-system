<?php
/**
 * 卡密管理核心类
 * 负责卡密的生成、验证、激活、查询
 */
class CardManager {
    
    /**
     * 批量生成卡密
     */
    public static function generateBatch($count, $amount, $duration, $remark = '') {
        $db = Database::getInstance();
        $batchNo = Security::generateBatchNo();
        $success = 0;
        $cards = [];
        
        for ($i = 0; $i < $count; $i++) {
            $key = Security::generateCardKey();
            $secret = Security::generateCardSecret();
            
            // 确保唯一性
            $exists = $db->fetch("SELECT id FROM cards WHERE card_key = ?", [$key]);
            if ($exists) {
                $i--; // 重试
                continue;
            }
            
            $result = $db->insert(
                "INSERT INTO cards (card_key, card_secret, amount, duration, batch_no, remark) VALUES (?, ?, ?, ?, ?, ?)",
                [$key, $secret, $amount, $duration, $batchNo, $remark]
            );
            
            if ($result) {
                $success++;
                $cards[] = [
                    'key' => $key,
                    'secret' => $secret,
                    'amount' => $amount,
                    'duration' => $duration
                ];
            }
        }
        
        return [
            'success' => true,
            'batch_no' => $batchNo,
            'count' => $success,
            'cards' => $cards
        ];
    }
    
    /**
     * 验证并激活卡密
     */
    public static function activate($cardKey, $cardSecret, $deviceId = '') {
        $db = Database::getInstance();
        
        // 查找卡密
        $card = $db->fetch(
            "SELECT * FROM cards WHERE card_key = ? AND card_secret = ?",
            [strtoupper(trim($cardKey)), trim($cardSecret)]
        );
        
        if (!$card) {
            return ['success' => false, 'msg' => '卡密不存在或已失效'];
        }
        
        // 检查状态
        if ($card['status'] == 1) {
            return ['success' => false, 'msg' => '卡密已被使用'];
        }
        if ($card['status'] == 2) {
            return ['success' => false, 'msg' => '卡密已过期'];
        }
        
        // 检查有效期
        if ($card['expired_at'] && $card['expired_at'] < time()) {
            $db->update("UPDATE cards SET status = 2 WHERE id = ?", [$card['id']]);
            return ['success' => false, 'msg' => '卡密已过期'];
        }
        
        // 激活
        $now = time();
        $expireTime = $now + ($card['duration'] * 86400);
        
        $db->update(
            "UPDATE cards SET status = 1, activated_at = ?, expired_at = ?, device_id = ? WHERE id = ?",
            [$now, $expireTime, $deviceId, $card['id']]
        );
        
        // 记录日志
        $db->insert(
            "INSERT INTO activation_logs (card_id, device_id, ip, user_agent) VALUES (?, ?, ?, ?)",
            [$card['id'], $deviceId, Security::getClientIp(), $_SERVER['HTTP_USER_AGENT'] ?? '']
        );
        
        return [
            'success' => true,
            'msg' => '激活成功',
            'data' => [
                'amount' => $card['amount'],
                'duration' => $card['duration'],
                'activated_at' => date('Y-m-d H:i:s', $now),
                'expired_at' => date('Y-m-d H:i:s', $expireTime),
                'card_key' => $card['card_key']
            ]
        ];
    }
    
    /**
     * 查询卡密状态
     */
    public static function queryStatus($cardKey, $cardSecret) {
        $db = Database::getInstance();
        
        $card = $db->fetch(
            "SELECT card_key, amount, duration, status, activated_at, expired_at, device_id, created_at 
             FROM cards WHERE card_key = ? AND card_secret = ?",
            [strtoupper(trim($cardKey)), trim($cardSecret)]
        );
        
        if (!$card) {
            return ['success' => false, 'msg' => '卡密不存在'];
        }
        
        $statusText = ['未使用', '已激活', '已过期', '已禁用'][$card['status']] ?? '未知';
        
        return [
            'success' => true,
            'data' => [
                'card_key' => $card['card_key'],
                'amount' => $card['amount'],
                'duration' => $card['duration'],
                'status' => $statusText,
                'status_code' => $card['status'],
                'activated_at' => $card['activated_at'] ? date('Y-m-d H:i:s', $card['activated_at']) : '-',
                'expired_at' => $card['expired_at'] ? date('Y-m-d H:i:s', $card['expired_at']) : '-',
                'device_id' => $card['device_id'] ?: '-',
                'created_at' => date('Y-m-d H:i:s', $card['created_at'])
            ]
        ];
    }
    
    /**
     * 获取卡密列表（后台）
     */
    public static function getCards($page = 1, $pageSize = 20, $status = -1, $search = '') {
        $db = Database::getInstance();
        $where = [];
        $params = [];
        
        if ($status >= 0) {
            $where[] = "status = ?";
            $params[] = $status;
        }
        if ($search) {
            $where[] = "(card_key LIKE ? OR batch_no LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $offset = ($page - 1) * $pageSize;
        
        $total = $db->fetch("SELECT COUNT(*) as cnt FROM cards $whereSql", $params)['cnt'];
        $cards = $db->fetchAll(
            "SELECT * FROM cards $whereSql ORDER BY id DESC LIMIT ? OFFSET ?",
            array_merge($params, [$pageSize, $offset])
        );
        
        return [
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
            'data' => $cards
        ];
    }
    
    /**
     * 禁用卡密
     */
    public static function disableCard($cardId) {
        $db = Database::getInstance();
        return $db->update("UPDATE cards SET status = 3 WHERE id = ?", [$cardId]);
    }
    
    /**
     * 删除卡密
     */
    public static function deleteCard($cardId) {
        $db = Database::getInstance();
        return $db->delete("DELETE FROM cards WHERE id = ?", [$cardId]);
    }
    
    /**
     * 导出卡密
     */
    public static function exportCards($batchNo = '', $status = -1) {
        $db = Database::getInstance();
        $where = [];
        $params = [];
        
        if ($batchNo) {
            $where[] = "batch_no = ?";
            $params[] = $batchNo;
        }
        if ($status >= 0) {
            $where[] = "status = ?";
            $params[] = $status;
        }
        
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        return $db->fetchAll("SELECT * FROM cards $whereSql ORDER BY id DESC", $params);
    }
    
    /**
     * 统计概览
     */
    public static function getStats() {
        $db = Database::getInstance();
        
        $total = $db->fetch("SELECT COUNT(*) as cnt FROM cards")['cnt'];
        $unused = $db->fetch("SELECT COUNT(*) as cnt FROM cards WHERE status = 0")['cnt'];
        $activated = $db->fetch("SELECT COUNT(*) as cnt FROM cards WHERE status = 1")['cnt'];
        $expired = $db->fetch("SELECT COUNT(*) as cnt FROM cards WHERE status = 2")['cnt'];
        $totalAmount = $db->fetch("SELECT SUM(amount) as sum FROM cards WHERE status = 1")['sum'] ?? 0;
        $todayActivated = $db->fetch(
            "SELECT COUNT(*) as cnt FROM cards WHERE status = 1 AND activated_at > ?",
            [strtotime('today')]
        )['cnt'];
        
        return [
            'total' => $total,
            'unused' => $unused,
            'activated' => $activated,
            'expired' => $expired,
            'total_amount' => $totalAmount,
            'today_activated' => $todayActivated
        ];
    }
}
