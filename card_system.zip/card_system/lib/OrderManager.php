<?php
/**
 * 订单管理类
 * 处理前台购买流程
 */
class OrderManager {
    
    /**
     * 创建订单
     */
    public static function createOrder($amount, $paymentMethod, $contactInfo = '') {
        $db = Database::getInstance();
        
        $orderNo = Security::generateOrderNo();
        
        $id = $db->insert(
            "INSERT INTO orders (order_no, amount, payment_method, contact_info) VALUES (?, ?, ?, ?)",
            [$orderNo, $amount, $paymentMethod, $contactInfo]
        );
        
        if ($id) {
            return ['success' => true, 'order_no' => $orderNo, 'id' => $id];
        }
        return ['success' => false, 'msg' => '创建订单失败'];
    }
    
    /**
     * 完成订单并分配卡密
     */
    public static function completeOrder($orderNo, $cardId = null) {
        $db = Database::getInstance();
        
        $order = $db->fetch("SELECT * FROM orders WHERE order_no = ?", [$orderNo]);
        if (!$order) return ['success' => false, 'msg' => '订单不存在'];
        if ($order['status'] == 1) return ['success' => false, 'msg' => '订单已完成'];
        
        // 如果没有指定卡密，自动分配一张未使用的
        if (!$cardId) {
            $card = $db->fetch(
                "SELECT id FROM cards WHERE status = 0 ORDER BY id ASC LIMIT 1"
            );
            if (!$card) return ['success' => false, 'msg' => '暂无可用卡密'];
            $cardId = $card['id'];
        }
        
        // 更新订单
        $db->update(
            "UPDATE orders SET status = 1, card_id = ?, paid_at = ? WHERE order_no = ?",
            [$cardId, time(), $orderNo]
        );
        
        // 获取卡密详情
        $card = $db->fetch("SELECT card_key, card_secret FROM cards WHERE id = ?", [$cardId]);
        
        return [
            'success' => true,
            'msg' => '支付成功',
            'card_key' => $card['card_key'],
            'card_secret' => $card['card_secret']
        ];
    }
    
    /**
     * 获取订单列表（后台）
     */
    public static function getOrders($page = 1, $pageSize = 20, $status = -1) {
        $db = Database::getInstance();
        $where = [];
        $params = [];
        
        if ($status >= 0) {
            $where[] = "status = ?";
            $params[] = $status;
        }
        
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $offset = ($page - 1) * $pageSize;
        
        $total = $db->fetch("SELECT COUNT(*) as cnt FROM orders $whereSql", $params)['cnt'];
        $orders = $db->fetchAll(
            "SELECT o.*, c.card_key FROM orders o 
             LEFT JOIN cards c ON o.card_id = c.id 
             $whereSql ORDER BY o.id DESC LIMIT ? OFFSET ?",
            array_merge($params, [$pageSize, $offset])
        );
        
        return ['total' => $total, 'data' => $orders];
    }
}
