<?php
/**
 * 安全工具类
 * 处理加密、哈希、CSRF、IP限制等
 */
class Security {
    
    /**
     * 生成随机字符串
     */
    public static function randomString($length = 32, $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') {
        $result = '';
        $max = strlen($chars) - 1;
        for ($i = 0; $i < $length; $i++) {
            $result .= $chars[random_int(0, $max)];
        }
        return $result;
    }
    
    /**
     * 生成卡号（带校验）
     * 格式: XXXX-XXXX-XXXX-XXXX
     */
    public static function generateCardKey() {
        $parts = [];
        for ($i = 0; $i < 4; $i++) {
            $parts[] = self::randomString(4, 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789');
        }
        return implode('-', $parts);
    }
    
    /**
     * 生成卡密
     */
    public static function generateCardSecret() {
        return self::randomString(CARD_SECRET_LENGTH, 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789abcdefghjkmnpqrstuvwxyz');
    }
    
    /**
     * 密码哈希
     */
    public static function hashPassword($password) {
        if (defined('PASSWORD_ARGON2ID')) {
            return password_hash($password, PASSWORD_ARGON2ID, [
                'memory_cost' => 65536,
                'time_cost' => 4,
                'threads' => 2
            ]);
        }
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
    
    /**
     * 验证密码
     */
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * 生成CSRF Token
     */
    public static function generateCsrfToken() {
        if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
            $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        }
        return $_SESSION[CSRF_TOKEN_NAME];
    }
    
    /**
     * 验证CSRF Token
     */
    public static function verifyCsrfToken($token) {
        if (!isset($_SESSION[CSRF_TOKEN_NAME])) return false;
        return hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
    }
    
    /**
     * 获取客户端IP
     */
    public static function getClientIp() {
        $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($headers as $h) {
            if (!empty($_SERVER[$h])) {
                $ip = explode(',', $_SERVER[$h])[0];
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return '0.0.0.0';
    }
    
    /**
     * 生成订单号
     */
    public static function generateOrderNo() {
        return 'ORD' . date('YmdHis') . self::randomString(6, '0123456789');
    }
    
    /**
     * 生成批次号
     */
    public static function generateBatchNo() {
        return 'B' . date('YmdHis') . self::randomString(4, '0123456789');
    }
    
    /**
     * 加密数据
     */
    public static function encrypt($data) {
        $key = hash('sha256', APP_SECRET);
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
        return base64_encode($iv . base64_decode($encrypted));
    }
    
    /**
     * 解密数据
     */
    public static function decrypt($data) {
        $key = hash('sha256', APP_SECRET);
        $data = base64_decode($data);
        if (strlen($data) < 16) return false;
        $iv = substr($data, 0, 16);
        $encrypted = base64_encode(substr($data, 16));
        return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
    }
    
    /**
     * 检查登录尝试次数
     */
    public static function checkLoginAttempts($ip) {
        $file = '/tmp/card_system_data/login_attempts_' . md5($ip) . '.json';
        $attempts = [];
        if (file_exists($file)) {
            $attempts = json_decode(file_get_contents($file), true) ?: [];
        }
        $now = time();
        $attempts = array_filter($attempts, function($t) use ($now) {
            return ($now - $t) < LOGIN_LOCK_TIME;
        });
        return count($attempts) < MAX_LOGIN_ATTEMPTS;
    }
    
    /**
     * 记录登录失败
     */
    public static function recordLoginFailure($ip) {
        $file = '/tmp/card_system_data/login_attempts_' . md5($ip) . '.json';
        $attempts = [];
        if (file_exists($file)) {
            $attempts = json_decode(file_get_contents($file), true) ?: [];
        }
        $attempts[] = time();
        file_put_contents($file, json_encode($attempts), LOCK_EX);
    }
    
    /**
     * 清除登录失败记录
     */
    public static function clearLoginAttempts($ip) {
        $file = '/tmp/card_system_data/login_attempts_' . md5($ip) . '.json';
        if (file_exists($file)) unlink($file);
    }
    
    /**
     * 安全输出
     */
    public static function escape($str) {
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * 验证卡密格式
     */
    public static function validateCardFormat($key, $secret) {
        if (!preg_match('/^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/', $key)) {
            return false;
        }
        if (!preg_match('/^[A-Za-z0-9]{' . CARD_SECRET_LENGTH . '}$/', $secret)) {
            return false;
        }
        return true;
    }
}
