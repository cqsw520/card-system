<?php
/**
 * 部署脚本 - 自动生成随机后台路径
 * 
 * 运行方式:
 *   php setup.php
 *   或在浏览器中访问（仅首次部署时）
 * 
 * 注意：数据库存储在 /tmp/card_system_data/ 确保可写
 */

echo "========================================\n";
echo "  卡密授权系统 - 部署工具 v1.0\n";
echo "========================================\n\n";

$baseDir = __DIR__;
$adminDirName = 'admin_' . substr(bin2hex(random_bytes(8)), 0, 12);
$adminDir = $baseDir . '/' . $adminDirName;

// 1. 创建后台目录
if (!is_dir($adminDir)) {
    mkdir($adminDir, 0755, true);
    echo "[✓] 创建后台目录: {$adminDirName}/\n";
} else {
    echo "[!] 后台目录已存在\n";
}

// 2. 复制后台文件到随机目录
$files = [
    'admin_template.php'    => 'login.php',
    'admin_index_template.php' => 'index.php',
    'admin_api_template.php'  => 'api.php',
    'admin_logout_template.php' => 'logout.php',
];

foreach ($files as $src => $dst) {
    $srcPath = $baseDir . '/' . $src;
    $dstPath = $adminDir . '/' . $dst;
    
    if (file_exists($srcPath)) {
        $content = file_get_contents($srcPath);
        file_put_contents($dstPath, $content);
        echo "[✓] 生成: {$adminDirName}/{$dst}\n";
    } else {
        echo "[✗] 源文件缺失: {$src}\n";
    }
}

// 3. 更新 config.php 中的 ADMIN_PATH
$configPath = $baseDir . '/config.php';
if (file_exists($configPath)) {
    $config = file_get_contents($configPath);
    if (strpos($config, '{{ADMIN_PATH}}') !== false) {
        $config = str_replace('{{ADMIN_PATH}}', $adminDirName, $config);
        file_put_contents($configPath, $config);
        echo "[✓] 更新 config.php 中的后台路径\n";
    } else {
        echo "[!] config.php 中的 ADMIN_PATH 已设置\n";
    }
}

// 4. 创建 /tmp 数据目录（数据库存储位置）
$tmpDataDir = '/tmp/card_system_data';
if (!is_dir($tmpDataDir)) {
    mkdir($tmpDataDir, 0777, true);
    echo "[✓] 创建临时数据目录: {$tmpDataDir}/\n";
}
chmod($tmpDataDir, 0777);

// 5. 创建 data 目录（存放安装锁等小文件）
$dataDir = $baseDir . '/data';
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
    echo "[✓] 创建数据目录\n";
}

// 6. 生成 .htaccess 保护敏感文件
file_put_contents($baseDir . '/.htaccess', 
    "# 禁止访问敏感文件\n" .
    "Options -Indexes\n\n" .
    "# 禁止直接访问 lib 和 db 目录\n" .
    "<Directory \"/lib\">\n" .
    "    Deny from all\n" .
    "</Directory>\n" .
    "<Directory \"/db\">\n" .
    "    Deny from all\n" .
    "</Directory>\n\n" .
    "# 禁止访问模板文件\n" .
    "<Files ~ \"_template\\.php$\">\n" .
    "    Deny from all\n" .
    "</Files>\n" .
    "<Files \"setup.php\">\n" .
    "    Deny from all\n" .
    "</Files>\n" .
    "<Files \"config.php\">\n" .
    "    Deny from all\n" .
    "</Files>\n"
);
echo "[✓] 生成 .htaccess 安全规则\n";

// 7. 保护 data 目录
file_put_contents($dataDir . '/.htaccess', "Deny from all\n");
file_put_contents($dataDir . '/index.html', '');

echo "\n========================================\n";
echo "  ✅ 部署完成！\n";
echo "========================================\n\n";
echo "📌 重要信息：\n";
echo "   后台目录: /{$adminDirName}/\n";
echo "   后台登录: /{$adminDirName}/login.php\n";
echo "   前台首页: /index.php\n";
echo "   安装向导: /install.php\n\n";
echo "⚠️  安全提醒：\n";
echo "   1. 请立即通过 install.php 完成安装\n";
echo "   2. 安装后删除 install.php 和 setup.php\n";
echo "   3. 请妥善保管后台路径，切勿泄露\n";
echo "   4. 数据库位于 /tmp (重启后需重新安装)\n\n";

// 生成部署信息文件
$deployInfo = [
    'admin_path' => $adminDirName,
    'deploy_time' => date('Y-m-d H:i:s'),
    'php_version' => PHP_VERSION,
    'db_location' => $tmpDataDir,
    'note' => 'Delete install.php and setup.php after installation!'
];
file_put_contents($dataDir . '/deploy_info.json', json_encode($deployInfo, JSON_PRETTY_PRINT));
chmod($dataDir . '/deploy_info.json', 0600);
echo "[✓] 部署信息已保存到 data/deploy_info.json (权限 600)\n";
echo "\n🚀 下一步：在浏览器中访问 install.php 完成安装\n";
